# Eclipse Multiplayer
This simple mod adds the 8 levels of Eclipse as selectable difficulties in singleplayer and multiplayer runs.

## Installation
Copy the `EclipseMultiplayer.dll` to your BepInEx plugins directory.
Or just use a mod manager, it's way easier

## Feedback
Any and all feedback is appreciated.

I've set up a simple Discord server to take feedback for my mods, found at [https://discord.gg/nfhzJad](https://discord.gg/nfhzJad)

## Changelog
### 1.0.0
 - Initial Release